var sea, ship;
var shipImg, seaImg;

function preload(){

 seaImg = loadImage("sea.png")
 shipImg = loadAnimation("ship-1.png","ship-2.png","ship-3.png", "ship-4.png" )

}

function setup(){
  createCanvas(400,400);
    
  sea = createSprite(400,400);
  sea.addImage(seaImg); 
  sea.velocityX = -3;
  ship = createSprite(130, 280)
  ship.addAnimation("moveship", shipImg);
  ship.scale = 0.25;

}

function draw() {
  background("blue");
    drawSprites();

 
}
